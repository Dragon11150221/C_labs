https://www.geeksforgeeks.org/left-shift-right-shift-operators-c-cpp/
https://stackoverflow.com/questions/111928/is-there-a-printf-converter-to-print-in-binary-format
https://c-for-dummies.com/blog/?p=1112
https://man7.org/linux/man-pages/man3/getline.3.html
https://overiq.com/c-programming-101/array-of-strings-in-c/
https://stackoverflow.com/questions/26126908/simple-way-to-create-multiple-strings-in-a-with-a-loop
https://en.cppreference.com/w/c/memory/malloc
https://www.tutorialspoint.com/c_standard_library/c_function_realloc.htm



p3 is >> ok?
