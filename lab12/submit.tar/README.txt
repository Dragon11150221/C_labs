https://www.gnu.org/software/make/manual/html_node/Cleanup.html
https://seisman.github.io/how-to-write-makefile/introduction.html
https://stackoverflow.com/questions/18468229/concatenate-two-char-strings-in-a-c-program/18468387
https://www.geeksforgeeks.org/comparator-function-of-qsort-in-c/
