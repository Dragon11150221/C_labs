reference:
redirect.c:   ./a.out < array.txt > 20_output.txt
https://stackoverflow.com/questions/1190870/i-need-to-generate-random-numbers-in-c
https://stackoverflow.com/questions/44789110/getting-values-for-an-array-using-scanf-function-in-c#:~:text=scanf(%22%25d%22%2C%20%26arr%5Bi%5D)%3B,you%20to%20the%20next%20element.