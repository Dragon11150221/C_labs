https://stackoverflow.com/questions/9642732/parsing-command-line-arguments-in-c
https://stackoverflow.com/questions/11578936/getting-a-bunch-of-crosses-initialization-error/11578973
