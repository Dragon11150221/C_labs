In this test_cases.tar archive you will find a set of valid and invalid instances that you can test your program with. You can look at example_outputs.txt for the expected output
for each instance. Due to random selection, the results may be different for each run (except in the case of invalid inputs). Our marking cases for the assignment may be different
from these test cases.
