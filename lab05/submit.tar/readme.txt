https://stackoverflow.com/questions/14099473/how-to-scanf-only-integer-and-repeat-reading-if-the-user-enters-non-numeric-char/14099507#14099507
