#include <stdio.h>

typedef union {
  float f;
  struct {
    unsigned int mantisa : 23;
    unsigned int exponent : 8;
    unsigned int sign : 1;
  } parts;
} float_cast;


int main(void){
  float_cast number;
  float n;
  printf("Enter a floating-point number: ");
  if (scanf("%f", &n) == 1){
    number.f = n;
    number.parts.exponent += 1;
    printf("Doubling becomes %f", number.f);
  }

  return 0;
}
