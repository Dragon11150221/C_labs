
reference:
lab 9
https://stackoverflow.com/questions/29254127/printing-leading-spaces-and-zeros-in-c-c
https://www.tutorialspoint.com/c_standard_library/c_function_freopen.htm
https://stackoverflow.com/questions/9206091/going-through-a-text-file-line-by-line-in-c
https://www.cnblogs.com/luxiaoxun/archive/2012/09
https://www.cnblogs.com/luxiaoxun/archive/2012/09/05/2671697.html
https://stackoverflow.com/questions/15685181/how-to-get-the-sign-mantissa-and-exponent-of-a-floating-point-number
