
/*
 * by Guohui Lin
 */

#include <stdio.h>

long FibonacciFinder(int index);

int main() {
	int index = 0;
	while (index >= 0){
		printf("Enter a position index: ");
		if (scanf("%d", &index) == 0 || index <= 0) {
			printf("Invalid index!\n");
			return -1;
		}
		printf("Term %d has a value: %ld\n", index, FibonacciFinder(index)); 
	}
	
	return 0;
}

long FibonacciFinder(int index) {
	switch(index) {
		case 1: return 0;
		case 2: return 1;
		case 3: return 2;
		default:
			return FibonacciFinder(index - 1) + FibonacciFinder(index - 2) + FibonacciFinder(index - 3);
	}
}	
