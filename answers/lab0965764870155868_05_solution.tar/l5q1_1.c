
/*
 * by Guohui Lin
 */

#include <stdio.h>

float calculate_addition(float num_one, float num_two);

int main() {
	
	float num1, num2;
	printf("Enter two numbers: ");
	if (scanf("%f%f", &num1, &num2) < 2)
		return 1;

	//set up two float variables and interface to accept from user input
	//print the sum of the entered two float numbers

	printf("%f\n", calculate_addition(num1, num2));
	return 0;
}

float calculate_addition(float num_one, float num_two) {
	return num_one + num_two;
}
