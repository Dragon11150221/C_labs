
/*
 * by Guohui Lin
 */

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void swap(int n, int row, int pos1, int pos2, int matrix[n][n]);
int balance(int n, int matrix[n][n]);
void initialization(int n, int matrix[n][n]);

int main(){
	int n = 0;
	printf("Enter the size of the matrix, a positive even integer: ");
	if (scanf("%d", &n) < 1 || n < 2 || n > 80 || n % 2 == 1) {
		printf("Invalid input!\n");
		return -1;
	}
	int matrix[n][n];
	initialization(n, matrix);
	
	printf("Initial %dx%d matrix:\n", n, n);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)
			printf("%d ", matrix[i][j]);
		printf("\n");	
	}
	
	printf("Total number of swaps is: %d\n", balance(n, matrix));
	printf("Final balanced matrix:\n");
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)
			printf("%d ", matrix[i][j]);
		printf("\n");	
	}
	return 0;
}

void initialization(int n, int matrix[n][n]){
	time_t t;
	srand((unsigned) time(&t));
	
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)
			 matrix[i][j] = 0;
		int oneCounter = 0;
		while (oneCounter < n / 2) {
			for (int j = 0; j < n; j++) {
				if (oneCounter == n / 2) break;
				int temp = rand() % 2;
				if ((matrix[i][j] == 0) && (temp == 1)) {
					matrix[i][j] = 1;
					oneCounter++;
				}
			}
		}
	}
	return;
}

int balance(int n, int matrix[n][n]){
	int swapCount = 0;
	while (1) {
		int pos1 = -1, pos2 = -1;
		for (int j = 0; j < n; j++) {
			int oneCounter = 0;
			for (int i = 0; i < n; i++)
				if (matrix[i][j] == 1)
					oneCounter++;
			if (oneCounter < n / 2)
				pos1 = j;
			else if (oneCounter > n / 2)
				pos2 = j;
		}
		if (pos1 >= 0) {
			int row = 0;
			while (1) {
				if (matrix[row][pos1] < matrix[row][pos2])
					break;
				else
					row++;
			}
			swap(n, row, pos1, pos2, matrix);
			swapCount++;
		}
		else
			break;
	}
	return swapCount;
}

void swap(int n, int row, int pos1, int pos2, int matrix[n][n]){
	int temp = matrix[row][pos2];
	matrix[row][pos2] = matrix[row][pos1];
	matrix[row][pos1] = temp;
	return;
}
