
#include <stdio.h>

int main() {
	
	//set up two float variables and interface to accept from user input
	//print the sum of the entered two float numbers

	printf("%f", calculate_addition(5, 5));
	return 0;
}

float calculate_addition(float num_one, float num_two) {
	return num_one + num_two;
}
