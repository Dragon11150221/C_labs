/*
 * Rylan, Rebecca, Guohui
 */

#include <stdio.h>
#include <string.h>

int main(void) {
  char string[16];
  printf("Enter a string of 15 characters (the first 15 accepted): ");
  if (!fgets(string, 16, stdin) || strlen(string) < 15) //
  	return -1;
  //scanf("%s", string);
  for (int i=0; i<3; i++) {
    for (int j=0; j<5; j++) {
      printf("%c", string[i*5+j]);
    }
    putchar('\n');
  }

  char p = string[2];
  int valid = 1;
  for (int i=0; i<3; i++) {
    for (int j=0; j<5; j++) {
      if (j >= 2-i && j <= 2+i) {
        if (string[i*5+j] != p) {
          //printf("This is not a pyramid: %c appears in a place of %c", string[i*5+j], p);
          printf("you have not entered a pyramid\n");
          valid = 0;
        }
      }
      else {
        if (string[i*5+j] == p) {
          //printf("This is not a pyramid: %c appears outside too", string[i*5+j]);
          printf("you have not entered a pyramid\n");
          valid = 0;
        }
      }
    }
  }
  if (valid) {
    printf("you have entered a pyramid\n");
  }
  return 0;
}
