/*
 * Rylan, Rebecca, Guohui
 */

#include <stdio.h>

int search(int arr[], int num, int start, int end);

int main(void) {
  int len;

  printf("Enter the length of the array: ");
  scanf("%d", &len);
  printf("Enter %d integers to be sorted: ", len);
  
  int arr[len];
  for (int i=0; i<len; i++) {
    scanf("%d", &arr[i]);
  }

  for (int i=0; i<len-1; i++) {
    for (int j=0; j<len-1-i; j++) {
      if (arr[j] > arr[j+1]) {
        int temp = arr[j];
        arr[j] = arr[j+1];
        arr[j+1] = temp;
      }
    }
  }

  printf("In sorted non-decreasing order: ");
  for (int i=0; i<len; i++) {
    printf("%d ", arr[i]);
  }
  putchar('\n');

  int num;
  printf("Enter the integer you wish to locate: ");
  if (scanf("%d", &num) == 1) {
  	//printf("num = %d\n", num);
  	int result = search(arr, num, 0, len-1);
    printf("It's found at position/index %d\n", result);
  }
  return 0;
}

int search(int arr[], int num, int start, int end) {
  int mid = start + (end - start) / 2;
  //if (num < arr[start] || num > arr[end] || (end == start && arr[mid] != num)){
  if (end == start && arr[mid] != num){
    return -1;
  }
  else if (arr[mid] == num) {
    return mid;
  }
  else if (arr[mid] < num) { //start < end
  	if (start < mid)
		return search(arr, num, mid, end);
	else
		return search(arr, num, mid+1, end);
  }
  else if (arr[mid] > num) {
    return search(arr, num, start, mid);
  }
  else {
    return -1;
  }
}
