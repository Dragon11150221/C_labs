/*
 * Rylan, Rebecca, Guohui
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	char string[100];
	char mode;
	while (1) {
		printf("Integer conversion in decimal (d), octal (o), or hexadecimal (h)? ");
		scanf("%c", &mode);
		getchar();
		if (mode == 'd' || mode == 'o' || mode == 'h')
			break;
	}

	while (1) {
		printf("Enter a message: ");
		int i = 0;

		while (1) {
			scanf("%c", &string[i]);
			if (string[i] == '\n') {
				string[i] = '\0';
				break;
			}
			i++;
		}

		if ((string[0] == 'E' || string[0] == 'e')
			&& (string[1] == 'X' || string[1] == 'x')
			&& (string[2] == 'I' || string[2] == 'i')
			&& (string[3] == 'T' || string[3] == 't')
			&& (string[4] == '\0'))
			exit(0);

		i = 0;
		while (1) {
			if (string[i] == '\0') {
				putchar('\n');
				break;
			}
			switch (mode) {
			case 'd':
				printf("%d ", (int)string[i]);
				break;
			case 'o':
				printf("%o ", (int)string[i]);
				break;
			case 'h':
				printf("%X ", (int)string[i]);
			}
			i++;
		}
	}
	return 0;
}
