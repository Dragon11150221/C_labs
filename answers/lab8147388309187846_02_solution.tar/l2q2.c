
/*
 * Guohui Lin
 */
 
#include <stdio.h>

int main () {
	int amount;
	
	printf("Enter a dollar amount: ");
	if (scanf("%d", &amount) && amount > 0) {
		if (amount / 100 > 0)
			printf("$100 bills: %d\n", amount / 100);
		amount %= 100;
		if (amount / 20 > 0)
			printf(" $20 bills: %d\n", amount / 20);
		amount %= 20;
		if (amount / 2 > 0)
			printf("   Toonies: %d\n", amount / 2);
		amount %= 2;
		if (amount > 0)
			printf("   Loonies: %d\n", amount);
	}

	return 0;
} 
