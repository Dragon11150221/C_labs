
/*
 * Guohui Lin
 */
 
#include <stdio.h>

int main () {
	int number;
	float fee = 25.0;
	
	printf("How many windows do you have: ");
	if (scanf("%d", &number) && number > 0) {
		if (number <= 24)
			fee += number * 8;
		else if (number <= 49)
			fee += number * 8 * 0.95;
		else if (number <= 99)
			fee += number * 8 * 0.90;
		else if (number <= 499)
			fee += number * 8 * 0.80;
		else
			fee += number * 8 * 0.60;

		printf("Your estimate for window cleaning is: %g\n", fee);
	}

	return 0;
} 
