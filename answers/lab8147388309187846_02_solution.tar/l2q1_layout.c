
/*
 * Guohui Lin
 */
 
#include <stdio.h>

int main () {
	int number_one, number_two;

	number_one = 10, number_two = 5;
	printf("The total is %d\n", (number_one + 10 - number_two) / 5);

	return 0;
} 

/*
   int main ( ) {int number_one,number_two;number_one=10,number_two

= 5; printf              ("The total is %d\n",(number_one+10-number_two)/5);} 
*/
