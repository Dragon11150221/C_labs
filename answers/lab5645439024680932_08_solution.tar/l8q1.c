
/* By Rylan Chin, minor revision by Guohui Lin
 */

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

int main() {
	srand(time(NULL));
	char buff[101];
	char *things[11];

	for (int i = 0; i < 11; i++) {
		fgets(buff, 101, stdin);
		things[i] = (char *) malloc(sizeof(char) * (strlen(buff)));
		strncpy(things[i], buff, strlen(buff)); // things[i] is not a string yet
		things[i][strlen(buff) - 1] = '\0';		// now becomes a string
	}

	char check;
	while(1) {
		while ((check = getchar()) != '\n')
			if (check == EOF) break;
		if (check == EOF) break;
		printf("%s\n", things[rand() % 11]);
	}

	for (int i = 0; i < 11; i++)
		free(things[i]);

	return 0;
}
