
/* by Rylan Chin, Guohui Lin
 */

#include <stdio.h>

void byte_value(int *n) {
	unsigned char *p;
	p = (unsigned char *)n;
	p += 2; // we know from l7q1 that our machines are small endian
	if (*p < 128) *p += 128;
	else {
		*p -= 128;
		p++;
		*p += 1;
	}
	return;
}

int main() {
	float x = 1.0;
	printf("Enter a floating-point number: ");
	if (scanf("%f", &x) == 1) {
		byte_value((int *) &x);
		printf("Doubling becomes %f\n", x);
	}

	return 0;
}
