
/* by Rylan Chin, Guohui Lin
 */

#include <stdio.h>

void gcd(int i, int j, int *a, int *b);

int main() {

	int i, j;
	printf("Enter two positive integers: ");
	scanf("%d%d", &i, &j);	// does not do input check
	int a, b;
	gcd(i, j, &a, &b);
	printf("GCD: %d = ", a * i + b * j);
	if (a >= 0)
		printf("%d * %d + ", a, i);
	else
		printf("(%d) * %d + ", a, i);
	if (b >= 0)
		printf("%d * %d\n", b, j);
	else
		printf("(%d) * %d\n", b, j);

	return 0;
}

void gcd(int i, int j, int *a, int *b) {
	if (i == j) {	// different settings can be for the base case
		*b = 1;
		*a = 0;
		return;
	}
	else if (i > j) {
		gcd(i - j, j, a, b);
		*b -= *a;
	}
	else {
		gcd(i, j - i, a, b);
		*a -= *b;
	}
	return;
}
