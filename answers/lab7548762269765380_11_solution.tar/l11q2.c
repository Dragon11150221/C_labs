
#include <stdio.h>

void bit_value(int *n) {
	int i = 1 << 23;
	*n += i;
	return;
}

int main() {
	float x = 1.0;
    bit_value((int *) &x);
	printf("Doubling becomes %f\n", x);
	
	printf("Enter a floating-point number: ");
	if (scanf("%f", &x) == 1)
		bit_value((int *) &x);
	printf("Doubling becomes %f\n", x);

	return 0;
}
