
/*
 * by Guohui Lin
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void pputs(char *p) {
	printf("Usage: %s input.txt\n", p);
	return;
}

int main(int argc, char *argv[]) {
	if (argc != 2) {
		pputs(argv[0]);
		return 2;
	}
	FILE *fp = fopen(argv[1], "r");
	if (fp == NULL) {
		pputs(argv[0]);
		return 1;
	}
	printf("Enter the number of output files: ");
	unsigned int n;
	if (scanf("%u", &n) == 0 || n == 0) {
		printf("Program terminates for doing nothing!\n");
		return 0;
	}
	int k = 1, temp = n;
	while ((temp /= 10) > 0) k++;
	char filename[100], string[256]; // these lengths are big enough
	for (int i = 1; i <= n; i++) {
		sprintf(string, "output%%.%dd.txt", k);
		sprintf(filename, string, i);
		FILE *fpout = fopen(filename, "w");
		fprintf(fpout, "Content of %s:\n\n", filename);
		while (fgets(string, 256, fp) != NULL)
			fputs(string, fpout);
		fclose(fpout);
		rewind(fp);
	}
	fclose(fp);

	return 0;
}
