
/*
 * Authors: Rebecca Walton, Guohui Lin
 * Course: CMPUT 201, Fall 2020
 */

#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#define N 100

void print_array (int[], int);
void print_results (int[], int, int, int);
void bubbleSort (int[], int);
void insertionSort (int[], int);
void mergeSort (int[], int);
void mergeUtility(int [], int, int, int*, int*);  
void merge (int[], int, int, int, int*, int*);
void quickSort (int[], int);
void quickUtility(int [], int, int, int*, int*); 
int partition (int [], int, int, int*, int*); 

int main () {
  int a[N];
  int n;
  char mode;

  // interface
  printf ("Enter the length of the array: ");
  if (!scanf ("%d", &n))
    return 1;
  printf ("Enter %d integers to be sorted: ", n);
  for (int i = 0; i < n; i++) {
      if (!scanf ("%d", &a[i]))
	  	return 1;
  }
  printf("Select from (a)ll | (b)ubblesort | (i)nsertionsort | (m)ergesort | (q)uicksort: ");
  if (!scanf (" %c", &mode))
    return 1;

  mode = tolower(mode);

  switch (mode) {
    case 'a':
      bubbleSort(a, n);
      insertionSort(a, n);
      mergeSort(a, n);
      quickSort(a, n); break;

    case 'b':
      bubbleSort(a, n); break;

    case 'i':
      insertionSort(a, n); break;

    case 'm':
      mergeSort(a, n); break;

    case 'q':
      quickSort(a, n); break;

    default:
      printf("Incorrect input.\n");
      return 1;
  }

  return 0;
}

void print_array(int a[], int n) {
  for (int i = 0; i < n; i++) {
      printf("%d ", a[i]);
  }
  printf("\n");
  return;
}

void print_results(int a[], int n, int ncomp, int nmov) {
  printf("In sorted non-decreasing order: ");
  print_array (a, n);
  printf("Number of comparisons: %d\n", ncomp);
  printf("Number of moves: %d\n", nmov);
  printf("---------------------------------------------------------------------\n");
}

void bubbleSort(int a[], int n) {
  printf("Bubblesort is deployed ...\n");

  int ncomp = 0, nmov = 0;
  int b[N];

  for (int i = 0; i < n; i++)
      b[i] = a[i];

  bool not_sorted = true;
  for (int i = 0; i < n - 1 && not_sorted; i++) {
      for (int j = 0; j < n - 1 - i; j++) {
	    not_sorted = false;
	    if (ncomp++, b[j] > b[j + 1]) {
	      not_sorted = true;
	      int temp = b[j + 1];
	      b[j + 1] = b[j];
	      b[j] = temp;
	      nmov += 2;
	    }
	  }
  }

  print_results(b, n, ncomp, nmov);
}

void insertionSort(int a[], int n) {
  printf ("Insertionsort is deployed ...\n");

  int ncomp = 0, nmov = 0;
  int b[N];

  for (int i = 0; i < n; i++)
      b[i] = a[i];

  int i, key, j;
  for (i = 1; i < n; i++) {
      key = b[i];
      j = i - 1;

      /* Move elements of arr[0..i-1], that are 
         greater than key, to one position ahead 
         of their current position */
      while (j >= 0 && (ncomp++, b[j] > key)) {
	    b[j + 1] = b[j];
	    nmov++;
	    j = j - 1;
	  }
      b[j + 1] = key;
      nmov++;
  }

  print_results(b, n, ncomp, nmov);
}

void mergeSort(int a[], int n) {
  printf ("Mergesort is deployed ...\n");

  int b[N], ncomp = 0, nmov = 0;

  for (int i = 0; i < n; i++)
      b[i] = a[i];

  mergeUtility(b, 0, n-1, &ncomp, &nmov);

  print_results(b, n, ncomp, nmov);
}

void mergeUtility(int a[], int l, int r, int *ncomp, int *nmov) {
  if (l < r)
    {
      // Same as (l+r)/2, but avoids overflow for  
      // large l and h  
      int m = l + (r - l) / 2;

      // Sort first and second halves  
      mergeUtility (a, l, m, ncomp, nmov);
      mergeUtility (a, m + 1, r, ncomp, nmov);

      merge(a, l, m, r, ncomp, nmov);
    }
}

void merge(int b[], int l, int m, int r, int *ncomp, int *nmov) {
  int i, j, k;
  int n1 = m - l + 1;
  int n2 = r - m;

  /* create temp arrays */
  int L[n1], R[n2];

  /* Copy data to temp arrays L[] and R[] */
  for (i = 0; i < n1; i++)
    L[i] = b[l + i];
  for (j = 0; j < n2; j++)
    R[j] = b[m + 1 + j];

  /* Merge the temp arrays back into arr[l..r] */
  i = 0;			// Initial index of first subarray  
  j = 0;			// Initial index of second subarray  
  k = l;			// Initial index of merged subarray  
  while (i < n1 && j < n2) {
      if ((*ncomp)++, L[i] <= R[j]) {
	    (*nmov)++;
	    b[k] = L[i];
	    i++;
	  }
      else {
	    (*nmov)++;
	    b[k] = R[j];
	    j++;
	  }
      k++;
  }

  /* Copy the remaining elements of L[], if there  
     are any */
  while (i < n1) {
      (*nmov)++;
      b[k] = L[i];
      i++;
      k++;
  }

  /* Copy the remaining elements of R[], if there  
     are any */
  while (j < n2) {
      (*nmov)++;
      b[k] = R[j];
      j++;
      k++;
  }
}

void quickSort(int a[], int n) {
  printf ("Quicksort is deployed ...\n");
  int b[N], ncomp = 0, nmov = 0;

  for (int i = 0; i < n; i++)
      b[i] = a[i];
    
  quickUtility(b, 0, n-1, &ncomp, &nmov);
  
  print_results (b, n, ncomp, nmov);
}

void quickUtility(int a[], int low, int high, int *ncomp, int *nmov) { 
    if (low < high) 
    { 
        /* pi is partitioning index, arr[p] is now 
           at right place */
        int pi = partition(a, low, high, ncomp, nmov); 
  
        // Separately sort elements before 
        // partition and after partition 
        quickUtility(a, low, pi - 1, ncomp, nmov); 
        quickUtility(a, pi + 1, high, ncomp, nmov); 
    } 
} 

int partition(int a[], int low, int high, int *ncomp, int *nmov) { 
    int pivot = a[high];    // pivot 
    int i = (low - 1);  // Index of smaller element 
  
    for (int j = low; j <= high- 1; j++) { 
        // If current element is smaller than the pivot 
        if ((*ncomp)++, a[j] < pivot) { 
            i++;    // increment index of smaller element 
            int temp = a[j];
            a[j] = a[i];
            a[i] = temp;
            (*nmov) += 2;
        } 
    } 
    int temp = a[i+1];
    a[i+1] = a[high];
    a[high] = temp;
    (*nmov) += 2;
    
    return (i + 1); 
} 
  
