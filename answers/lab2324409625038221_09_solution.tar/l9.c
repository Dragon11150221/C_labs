
/* by Rylan Chin, Guohui Lin
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define MAX_COOR 1000 // points in the area [0, MAX_COOR] x [0, MAX_COOR]

struct point {
	float x;
	float y;
	struct point *next;
};

float sample_distance(struct point *shape1, struct point *shape2, int k);
struct point *index_sample(struct point *shape, int k);
struct point *generate(int);
void printing(struct point *);
void cleanup(struct point *);

int main(int argc, char *argv[]) {
	srand(time(NULL));
	struct point *shape1, *shape2;

	int length1, length2;
	printf("Enter two integers in [1, 1000]: ");
	if (scanf("%d%d", &length1, &length2) < 2 || length1 < 1 || length1 > 1000 || length2 < 1 || length2 > 1000)
		return -1;

	shape1 = generate(length1);
	if (length1 == 1)
		printf("Shape1 with %d point: ", length1);
	else
		printf("Shape1 with %d points: ", length1);
	printing(shape1);

	shape2 = generate(length2);
	if (length2 == 1)
		printf("Shape2 with %d point: ", length2);
	else
		printf("Shape2 with %d points: ", length2);
	printing(shape2);

	int k;
	printf("Enter an integer in [2, 1000]: ");
	if (scanf("%d", &k) < 1 || k < 2 || length1 > 1000)
		return -2;

	struct point *k_sample_shape1 = index_sample(shape1, k), *k_sample_shape2 = index_sample(shape2, k);
	printf("%d-sample of Shape1: ", k);
	printing(k_sample_shape1);
	printf("%d-sample of Shape2: ", k);
	printing(k_sample_shape2);

	printf("The %d-sample distance is: %.3f\n", k, sample_distance(k_sample_shape1, k_sample_shape2, k));

	cleanup(k_sample_shape1);
	cleanup(k_sample_shape2);
	cleanup(shape1);
	cleanup(shape2);

	return 0;
}

struct point *generate(int length) {
	struct point *head = NULL;
	for (int i = 0; i < length; i++) {
		struct point *temp = malloc(sizeof (struct point));
		temp->x = (rand() % (1000 * MAX_COOR)) / 1000.0;
		temp->y = (rand() % (1000 * MAX_COOR)) / 1000.0;
		temp->next = head;
		head = temp;
	}
	return head;
}

void printing(struct point *head) {
	struct point *temp = head;
	printf("<");
	while (temp != NULL) {
		printf("(%.3f, %.3f)", temp->x, temp->y);
		temp = temp->next;
		if (temp != NULL)
			printf(", ");
	}
	printf(">\n");
	return;
}

void cleanup(struct point *head) {
	struct point *temp = head;
	while (head->next != NULL) {
		head = head->next;
		free(temp);
		temp = head;
	}
	free(head);
	return;
}

struct point *index_sample(struct point *shape, int k) { //do not damage the given shape
	int length = 0;
	struct point *temp = shape, *head =  malloc(sizeof(struct point)), *tail;
	while (temp != NULL) {
		length++;
		temp = temp->next;
	}
	*head = *shape;
	head->next = NULL;
	tail = head;
	for (int i = 1; i < k-1; i++) {
		temp = shape;
		for (int j = 0; j < i * length / (k-1); j++)
			temp = temp->next;
		struct point *temp2 = malloc(sizeof(struct point));
		*temp2 = *temp;
		tail->next = temp2;
		tail = temp2;
		tail->next = NULL;
	}
	while (temp->next != NULL) {
		temp = temp->next;
	}
	struct point *temp2 = malloc(sizeof(struct point));
	*temp2 = *temp;
	tail->next = temp2;

	return head;
}

float sample_distance(struct point *shape1, struct point *shape2, int k) {
	float distance = 0;
	for (int i = 0; i < k; i++) {
		distance += sqrt((shape1->x - shape2->x) * (shape1->x - shape2->x) + (shape1->y - shape2->y) * (shape1->y - shape2->y));
		shape1 = shape1->next;
		shape2 = shape2->next;
	}
	return distance;
}
