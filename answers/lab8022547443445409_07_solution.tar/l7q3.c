
/* by Guohui Lin
 */

#include <stdio.h>

void coefficient(int k, int a[], int *s) {
	if (k == 1) {
		*s = 0;
		a[0] = 1;
		return;
	}
	coefficient(k-1, a, s);
	int i = 0;
	while (a[i] == 1) a[i++] = -1;
	a[i] += 1;
	if (i > *s) (*s)++;

	return;
}

int main() {
	int a[8] = {0}; // since we are dealing with k in [1, 1000]
				// it would be a nice practice to use linked list, so that we can represent any integer
	int k, s = 0;
	printf("Enter a positive integer: ");
	scanf("%d", &k);
	coefficient(k, a, &s);
	printf("Coefficient sequence: ");
	for (int i = 0; i < s; i++)
		printf("%d, ", a[i]);
	printf("%d\n", a[s]);
	return 0;
}
