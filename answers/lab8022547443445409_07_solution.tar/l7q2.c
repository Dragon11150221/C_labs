
/* by Guohui Lin
 */

#include <stdio.h>

int helper(int a[], int n, int bound) {
	int j, min = 0;
	for (int i = 0; i < n; i++) {
		if (min == 0 && a[i] > bound) {
			min = a[i] - bound;
			j = i;
		}
		else if (a[i] > bound && a[i] - bound < min) {
			min = a[i] - bound;
			j = i;
		}
	}
	return j;	
}

int main() {
	int n;
	printf("Enter the length of the array: ");
	if (scanf("%d", &n) < 1 || n < 1)
		return 0;
	int a[n];
	printf("Enter %d distinct positive integers: ", n);
	for (int i = 0; i < n; i++) 
		if (scanf("%d", &a[i]) < 1)
			return 0;
	
	printf("Index order: ");
	int order[n];
	order[0] = helper(a, n, 0);
	for (int i = 1; i < n; i++) {
		order[i] = helper(a, n, a[order[i-1]]);
	}
	printf("%d", order[0]);
	for (int i = 1; i < n; i++)
		printf(", %d", order[i]);
	printf("\n");

	return 0;
}
