
/* by Guohui Lin
 */

#include <stdio.h>

void byte_value(int *n) {
	unsigned char *p;
	p = (unsigned char *)n;
	while (p < (unsigned char *)(n + 1)) {
		printf("%p, %hhu \n", p, *p);
		p++;
	}
	return;
}

int main() {
	int n = 1;
 	byte_value(&n);
	
	printf("Enter an integer: ");
	if (scanf("%d", &n) == 1)
		byte_value(&n);

	return 0;
}
