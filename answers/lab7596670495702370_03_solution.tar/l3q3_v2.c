
// Author: Rebecca Walton
// Course: CMPUT 201, Fall 2020
/*
 * Guohui lin
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main () {
   int alice = 0, bob = 0, numDice = 0;
   int aliceTurn = 1;
   
   /* Intializes random number generator */
   srand((unsigned) time(NULL));

   while (!(alice > 1000 || bob > 1000)) {
	   if (scanf("%d", &numDice) != 1 || numDice < 1 || numDice > 4) {
		   printf("Invalid input\n");
		   return 1;
	   }

	   int total = 0;
	   for (int i = 0; i < numDice; i++) {
		   total += rand() % 6 + 1;
	   }

	   switch (numDice) {
	   case 4:
		   total -= 20;
		   break;
	   case 3:
		   total -= 10;
		   break;
	   case 2:
		   total -= 5;
		   break;
	   default:
		   break;
	   }

	   if (aliceTurn) {
		   alice += total;
		   aliceTurn = 0;
	   } else {
		   bob += total;
		   aliceTurn = 1;
	   }
   }

   if (alice > bob) {
	   printf("Alice wins with %d points.\n", alice);
   } else {
	   printf("Bob wins with %d points.\n", bob);
   }
   
   return 0;
}
