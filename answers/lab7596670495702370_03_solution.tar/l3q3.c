
/*
 * Guohui Lin
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define Deduction 5

int main() {

	int sum_alice = 0, sum_bob = 0;
	//FILE *p = fopen("moves.txt", "w");
	
	srand((unsigned) time(NULL));   /* seed the random number generator */

	while (sum_alice < 1000 && sum_bob < 1000) {
		int current_alice = 0;
		//int num_alice = rand() % 4 + 1;
		//fprintf(p, "%d\n", num_alice);
		int num_alice;
		scanf("%d", &num_alice);
		for (int i = 0; i < num_alice; i++) {
			current_alice += rand() % 6 + 1;
		}
		current_alice -= Deduction * (num_alice - 1 + num_alice / 4);
		sum_alice += current_alice;
		if (sum_alice >= 1000) {
			printf("Alice wins with %d points.\n", sum_alice);
			break;
		}

		int current_bob = 0;
		//int num_bob = rand() % 4 + 1;
		//fprintf(p, "%d\n", num_bob);
		int num_bob;
		scanf("%d", &num_bob);
		for (int i = 0; i < num_bob; i++) {
			current_bob += rand() % 6 + 1;
		}
		current_bob -= Deduction * (num_bob - 1 + num_bob / 4);
		sum_bob += current_bob;
		if (sum_bob >= 1000) {
			printf("Bob wins with %d points.\n", sum_bob);
			break;
		}
	}
	//fclose(p);

	return 0;
}
