// Author: Rebecca Walton
// Course: CMPUT 201, Fall 2020

#include <stdio.h>

#define MAX_NUMS 20

int main() {
	int nums[MAX_NUMS];

	printf("Enter %d integers: ", MAX_NUMS);
	for (int i = 0; i < MAX_NUMS; i++) {
		if (scanf("%d", &nums[i]) != 1) {
			printf("Invalid value\n");
			return 1;
		}
	}

	int largest = nums[0];
	int secondLargest = nums[0];
	for (int i = 1; i < MAX_NUMS; i++) {
		if (nums[i] > largest) {
			secondLargest = largest;
			largest = nums[i];
		} else if (nums[i] > secondLargest) {
			secondLargest = nums[i];
		}
	}

	printf("Largest: %d\nSecond Largest: %d\n", largest, secondLargest);
	return 0;
}
