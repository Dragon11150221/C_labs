// Author: Rebecca Walton
// Course: CMPUT 201, Fall 2020

#include <stdio.h>

void printBottles(int bottleNum) {
	switch (bottleNum) {
		case 2:
			printf("%d bottles of beer on the wall,\n"
				   "%d bottles of beer.\n"
				   "Take one down, pass it around,\n"
				   "%d Bottle of beer on the wall.\n\n",
				   bottleNum, bottleNum, bottleNum - 1);
			break;
		case 1:
			printf("%d bottle of beer on the wall,\n"
				   "%d bottle of beer.\n"
				   "Take one down, pass it around,\n"
				   "%d Bottles of beer on the wall.\n\n",
				   bottleNum, bottleNum, bottleNum - 1);
			break;
		default:
			printf("%d bottles of beer on the wall,\n"
				   "%d bottles of beer.\n"
				   "Take one down, pass it around,\n"
				   "%d Bottles of beer on the wall.\n\n",
				   bottleNum, bottleNum, bottleNum - 1);
	}
}

int main() {
	int bottleNum = 99;

	while (bottleNum > 0) {
		printBottles(bottleNum);
		bottleNum--;
	}

	for (int i = 99; i > 0; i--) {
		printBottles(i);
	}

	bottleNum = 99;
	do {
		printBottles(bottleNum);
		bottleNum--;
	} while (bottleNum > 0);
	
	return 0;
}
