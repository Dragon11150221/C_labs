
/*
 * Guohui Lin
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct student {
	char *lastname;
	char *firstname;
	float assignments; // range [0, 21]
	float quizzes; // range [0, 14]
	float labs; // range [0, 30]
	float finalexam; // range [0, 30]
	float total; // range [0, 100]
	char grade; // range {F, D, C, B, A}
};

void printing(struct student *p, int n);
int comparator_name(const void *p, const void *q);
int comparator_assignments(const void *p, const void *q);
int comparator_quizzes(const void *p, const void *q);
int comparator_labs(const void *p, const void *q);
int comparator_finalexam(const void *p, const void *q);
int comparator_total(const void *p, const void *q);
int comparator_grade(const void *p, const void *q);

int main() {
	struct student cmput201[99];
	FILE *fpin;
	fpin = fopen("spreadsheet.txt", "r");
	char str[256];
	fgets(str, 256, fpin);
	//puts(str);
	for (int i = 0; i < 99; i++) {
		cmput201[i].lastname = malloc(100);
		fscanf(fpin, "%s", cmput201[i].lastname);
		cmput201[i].lastname = realloc(cmput201[i].lastname, strlen(cmput201[i].lastname) + 1);
		cmput201[i].firstname = malloc(100);
		fscanf(fpin, "%s", cmput201[i].firstname);
		cmput201[i].firstname = realloc(cmput201[i].firstname, strlen(cmput201[i].firstname) + 1);
		fscanf(fpin, "%f", &cmput201[i].assignments);
		fscanf(fpin, "%f", &cmput201[i].quizzes);
		fscanf(fpin, "%f", &cmput201[i].labs);
		fscanf(fpin, "%f", &cmput201[i].finalexam);
		cmput201[i].total = cmput201[i].assignments / 21  * 20 + cmput201[i].quizzes / 14 * 20 + cmput201[i].labs + cmput201[i].finalexam;
		cmput201[i].grade = '-';
	}
	fclose(fpin);

#ifdef SORTING
	printf("sort all students by [Name|Assignments|Quizzes|Labs|FinalExam|Total|Grade]: ");
	scanf("%s", str);
	if (strcmp(str, "Name") == 0) 
		qsort((void *)cmput201, 99, sizeof(struct student), comparator_name);
	else if (strcmp(str, "Assignments") == 0) 
		qsort((void *)cmput201, 99, sizeof(struct student), comparator_assignments);
	else if (strcmp(str, "Quizzes") == 0) 
		qsort((void *)cmput201, 99, sizeof(struct student), comparator_quizzes);
	else if (strcmp(str, "Labs") == 0) 
		qsort((void *)cmput201, 99, sizeof(struct student), comparator_labs);
	else if (strcmp(str, "FinalExam") == 0) 
		qsort((void *)cmput201, 99, sizeof(struct student), comparator_finalexam);
	else if (strcmp(str, "Total") == 0) 
		qsort((void *)cmput201, 99, sizeof(struct student), comparator_total);
	else if (strcmp(str, "Grade") == 0) 
		qsort((void *)cmput201, 99, sizeof(struct student), comparator_grade);
	else
		printf("Invalid sorting criterion!\n");
	printing(cmput201, 99);
#endif

#ifdef GRADING
	printf("enter four cutoffs for grade assignment: ");
	float ddd, ccc, bbb, aaa;
	scanf("%f%f%f%f", &ddd, &ccc, &bbb, &aaa);
	float gpa = 0.0;
	for (int i = 0; i < 99; i++) {
		if (cmput201[i].total < ddd) {
			cmput201[i].grade = 'F'; gpa += 0.0;}
		else if (cmput201[i].total < ccc) {
			cmput201[i].grade = 'D'; gpa += 1.0;}
		else if (cmput201[i].total < bbb) {
			cmput201[i].grade = 'C'; gpa += 2.0;}
		else if (cmput201[i].total < aaa) {
			cmput201[i].grade = 'B'; gpa += 3.0;}
		else {
			cmput201[i].grade = 'A'; gpa += 4.0;}
	}
	gpa /= 99;
	printf("the class average grade point is: %.2f\n", gpa);

	qsort((void *)cmput201, 99, sizeof(struct student), comparator_grade);
	printing(cmput201, 99);
#endif

	for (int i = 0; i < 99; i++) {
		free(cmput201[i].lastname);
		free(cmput201[i].firstname);
	}
	return 0;
}

void printing(struct student *p, int n) {
	printf("%-22s Assignments\tQuizzes\tLabs\tFinalExam\tTotal\tGrade\n", "Name");
	char str[100];
	for (int i = 0; i < n; i++) {
		sprintf(str, "%s %s", p[i].lastname, p[i].firstname);
		printf("%-30s %5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%c\n",
			str, p[i].assignments, p[i].quizzes, p[i].labs, p[i].finalexam, p[i].total, p[i].grade);
	}
	return;
}

int comparator_name(const void *p, const void *q) {
	if (strcmp(((struct student *)p)->lastname, ((struct student *)q)->lastname) == 0)
		return strcmp(((struct student *)p)->firstname, ((struct student *)q)->firstname);
	else
		return strcmp(((struct student *)p)->lastname, ((struct student *)q)->lastname);
}

int comparator_assignments(const void *p, const void *q) {
	float l = ((struct student *)p)->assignments;
	float r = ((struct student *)q)->assignments;
	if ((int) 100 * (l - r) == 0) 
		return comparator_name(p, q);
	return (int) 100 * (l - r);
}

int comparator_quizzes(const void *p, const void *q) {
	float l = ((struct student *)p)->quizzes;
	float r = ((struct student *)q)->quizzes;
	if ((int) 100 * (l - r) == 0)
		return comparator_name(p, q);
	return (int) 100 * (l - r);
}

int comparator_labs(const void *p, const void *q) {
	float l = ((struct student *)p)->labs;
	float r = ((struct student *)q)->labs;
	if ((int) 100 * (l - r) == 0) 
		return comparator_name(p, q);
	return (int) 100 * (l - r);
}

int comparator_finalexam(const void *p, const void *q) {
	float l = ((struct student *)p)->finalexam;
	float r = ((struct student *)q)->finalexam;
	if ((int) 100 * (l - r) == 0)
		return comparator_name(p, q);
	return (int) 100 * (l - r);
}

int comparator_total(const void *p, const void *q) {
	float l = ((struct student *)p)->total;
	float r = ((struct student *)q)->total;
	if ((int) 100 * (l - r) == 0)
		return comparator_name(p, q);
	return (int) 100 * (l - r);
}

int comparator_grade(const void *p, const void *q) {
	char l = ((struct student *)p)->grade;
	char r = ((struct student *)q)->grade;
	if (l == r) 
		return comparator_name(p, q);
	return (r - l);
}

