
/*
 * by Guohui Lin
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

void pputs(char *p) {
	printf("Usage: %s [add|sub|mul|div|mod|pow|log Num Num]\n", p);
	return;
}

void isitnum(char *ptr, char *p, int k) { // check whether argv[2], argv[3] are numbers or not
	if (*ptr != '\0') {
		pputs(p);
		exit(k);
	}
	return;
}

int main(int argc, char *argv[]) {
	if (argc != 4) {
		pputs(argv[0]);
		return 4;
	}
	
	long int int_num1, int_num2;
	float float_num1, float_num2;
	char *ptr;
	if (strcmp(argv[1], "add") == 0 || strcmp(argv[1], "sub") == 0 || strcmp(argv[1], "mul") == 0 || strcmp(argv[1], "div") == 0) {
		bool is_int = 1;
		int_num1 = strtol(argv[2], &ptr, 10);
		if (*ptr != '\0') {
			is_int = 0;
			float_num1 = strtof(argv[2], &ptr);
			isitnum(ptr, argv[0], 2);
		} else
			float_num1 = (float) int_num1;

		int_num2 = strtol(argv[3], &ptr, 10);
		if (*ptr != '\0') {
			is_int = 0;
			float_num2 = strtof(argv[3], &ptr);
			isitnum(ptr, argv[0], 3);
		} else
			float_num2 = (float) int_num2;

		if (is_int) {
			if (strcmp(argv[1], "add") == 0)
				printf("addition for %s, %s is %ld\n", argv[2], argv[3], int_num1 + int_num2);
			else if (strcmp(argv[1], "sub") == 0)
				printf("subtraction for %s, %s is %ld\n", argv[2], argv[3], int_num1 - int_num2);
			else if (strcmp(argv[1], "mul") == 0)
				printf("multiplication for %s, %s is %ld\n", argv[2], argv[3], int_num1 * int_num2);
			else if (strcmp(argv[1], "div") == 0) { // divoisor cannot be 0
				if (int_num2 == 0)
					printf("division cannot be performed for %s, %s\n", argv[2], argv[3]);
				else
					printf("division for %s, %s is %ld\n", argv[2], argv[3], int_num1 / int_num2);
			}
		} else {
			if (strcmp(argv[1], "add") == 0)
				printf("addition for %s, %s is %f\n", argv[2], argv[3], float_num1 + float_num2);
			else if (strcmp(argv[1], "sub") == 0)
				printf("subtraction for %s, %s is %f\n", argv[2], argv[3], float_num1 - float_num2);
			else if (strcmp(argv[1], "mul") == 0)
				printf("multiplication for %s, %s is %f\n", argv[2], argv[3], float_num1 * float_num2);
			else if (strcmp(argv[1], "div") == 0) {
				if (float_num2 == 0.0)
					printf("division cannot be performed for %s, %s\n", argv[2], argv[3]);
				else
					printf("division for %s, %s is %f\n", argv[2], argv[3], float_num1 / float_num2);
			}
		}
	} else if (strcmp(argv[1], "mod") == 0) {
		int_num1 = strtol(argv[2], &ptr, 10);
		isitnum(ptr, argv[0], 2);
		int_num2 = strtol(argv[3], &ptr, 10);
		isitnum(ptr, argv[0], 3);
		if (int_num2 == 0)
			printf("modulo cannot be performed for %s, %s\n", argv[2], argv[3]);
		else
			printf("modulo for %s, %s is %ld\n", argv[2], argv[3], int_num1 % int_num2);
	} else if (strcmp(argv[1], "pow") == 0 || strcmp(argv[1], "log") == 0) {
		float_num1 = strtof(argv[2], &ptr);
		isitnum(ptr, argv[0], 2);
		float_num2 = strtof(argv[3], &ptr);
		isitnum(ptr, argv[0], 3);
		if (strcmp(argv[1], "pow") == 0) // some pow has result NaN
			printf("power for %s, %s is %f\n", argv[2], argv[3], pow(float_num1, float_num2));
		else {
			//if (float_num1 <= 0.0 || float_num2 <= 0.0)
			//	printf("logarithm cannot be performed for %s, %s\n", argv[2], argv[3]);
			//else
				printf("logarithm for %s, %s is %f\n", argv[2], argv[3], log(float_num2) / log(float_num1));
		}
	} else {
		pputs(argv[0]);
		return 1;
	}

	return 0;
}
