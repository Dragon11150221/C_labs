// Author: Rebecca Walton
// Course: CMPUT 201, Fall 2020

#include <stdio.h>
#include <stdlib.h>
#include <libgen.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

typedef struct Number {
	int isFloat;
	float f;
	char *str;
} Number;

// printUsage prints the usage message
void printUsage(char *name) {
	printf("Usage: ./%s [add|sub|mul|div|mod|pow|log Num Num]\n", basename(name));
}

// parseNumber parses the number and stores it's string value as well as it's float
// as well as indicates if it should be printed as a float or an integer using a Number
// struct
Number *parseNumber(char *num) {
	Number *n = NULL;
	char *end;
	int isFloat = 0;

	// make sure the argument is a number
	for (int i = 0; i < strlen(num); i++) {
		if (!isdigit(num[i])) {
			if (num[i] == '.' && !isFloat) {
				// saw first period so it's a float
				isFloat = 1;
			} else if (i == 0 && (num[i] == '+' || num[i] == '-')) {
				// the string can start with +/-
				continue;
			} else {
				// saw an invalid character, or a second period
				return NULL;
			}
		}
	}

	// store if it's a float and the string value for printing
	n = malloc(sizeof(Number));
	n->isFloat = isFloat;
	n->str = num;

	// convert to a float
	n->f = strtof(num, &end);
	if (n->f == 0 && num == end) {
		free(n);
		return NULL;
	}

	return n;
}

// compute determines the result of the operation provided on the two numbers
int compute(char *op, Number *n1, Number *n2) {
	const char *operations[] = {"addition", "subtraction", "multiplication",
		"division", "modulo", "power", "logarithm"};
	int opIndex = -1;
	int printAsFloat = 0;
	float result = 0;
			
	if (strcmp(op, "add") == 0) {
		opIndex = 0;
		result = n1->f + n2->f;
	} else if (strcmp(op, "sub") == 0) {
		opIndex = 1;
		result = n1->f - n2->f;
	} else if (strcmp(op, "mul") == 0) {
		opIndex = 2;
		result = n1->f * n2->f;
	} else if (strcmp(op, "div") == 0) {
		opIndex = 3;

		// can't divide by 0
		if (n2->f == 0.0) {
			printf("%s cannot be performed for %s, %s\n", operations[opIndex], n1->str, n2->str);
			return 0;
		}
		result = n1->f / n2->f;
	} else if (strcmp(op, "mod") == 0) {
		opIndex = 4;

		// can't perform mod on floats
		if (n1->isFloat || n2->isFloat) {
			printf("%s cannot be performed for %s, %s\n", operations[opIndex], n1->str, n2->str);
			return 0;
		}
		
		result = (int)n1->f % (int)n2->f;
	} else if (strcmp(op, "pow") == 0) {
		opIndex = 5;
		result = pow(n1->f, n2->f);
		printAsFloat = 1;
	} else if (strcmp(op, "log") == 0) {
		opIndex = 5;
		result = log(n2->f)/log(n1->f);
		printAsFloat = 1;
	}

	// operation not found
	if (opIndex == -1) {
		return 1;
	}

	// print the appropriate result
	if (n1->isFloat || n2->isFloat || printAsFloat) {
		printf("%s for %s, %s is %f\n", operations[opIndex], n1->str, n2->str, result);
	} else {
		printf("%s for %s, %s is %d\n", operations[opIndex], n1->str, n2->str, (int)result);
	}

	return 0;
}

int main(int argc, char *argv[]) {
	char *operation = NULL;
	Number *n1 = NULL;
	Number *n2 = NULL;

	// should have 4 args -> program namd + operation + 2 nums
	if (argc != 4) {
		printUsage(argv[0]);
		return 1;
	}

	// second argument should be operation
	operation = argv[1];

	// parse the first number
	n1 = parseNumber(argv[2]);
	if (n1 == NULL) {
		printUsage(argv[0]);
		return 1;
	}

	// parse the second number
	n2 = parseNumber(argv[3]);
	if (n2 == NULL) {
		free(n1);
		printUsage(argv[0]);
		return 1;
	}

	// compute the result of the operation provided on the two numbers
    int fail = compute(operation, n1, n2);
	free(n1);
	free(n2);

	// if couldn't find the operation
	if (fail) {
		printUsage(argv[0]);
		return 1;
	}

	return 0;
}
