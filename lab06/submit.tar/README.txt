handle cases?


Reference:
https://www.geeksforgeeks.org/merge-sort/
https://www.geeksforgeeks.org/quick-sort/
